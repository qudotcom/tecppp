# Event Bus Contracts (TECPAP T1)

**Rules of Engagement:**
1. **Schema Validation:** All payloads must strictly match the JSON shapes defined below.
2. **Timestamps:** All `ts_event` fields must be ISO-8601 formatted UTC strings.
3. **Immutability:** Once an event is published, it cannot be recalled. Compensating events must be issued for corrections.

---

### Topic: `of.created`
* **Emitted by:** Agent A (ERP Bridge & ETL)
* **Consumed by:** Agent G (FSC Audit), Agent D (Rules Engine)
* **Trigger:** A new Ordre de Fabrication is created or released in Sage X3.
* **Payload:**
```json
{
  "of_id_full": "MFG2603STP01119",
  "of_id_short": "26/1119",
  "sku": "SFCPP282027KB80-4",
  "client": "LITTEL MA",
  "fsc_required_tier": "F1", // Can be "F1", "F2", "F3", "P1", "P2", "P3", or null
  "target_quantity": 37500,
  "specs": {
    "laize": 98,
    "grammage": 80,
    "type_papier": "KB"
  },
  "bom": [
    { "type": "colle_fond", "ref": "5000" },
    { "type": "colle_long", "ref": "5000" },
    { "type": "carton", "ref": "402839" }
  ],
  "ts_event": "2026-04-03T10:00:00Z"
}
