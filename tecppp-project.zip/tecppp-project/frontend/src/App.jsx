import { useState, useCallback } from 'react';
import axios from 'axios';
import {
  Factory,
  Search,
  CheckCircle2,
  XCircle,
  Printer,
  Tag,
  Loader2,
  AlertTriangle,
  PackageCheck,
  Layers,
  Droplets,
  CircleDot,
  X,
  ChevronRight,
} from 'lucide-react';
import './App.css';

const RULES_API = 'http://localhost:4000';
const LABELS_API = 'http://localhost:4001';

/* ------------------------------------------------------------------ */
/*  Status Badge Component                                            */
/* ------------------------------------------------------------------ */
function StatusBadge({ passed, label, icon: Icon, detail }) {
  const ok = passed === true;
  const fail = passed === false;
  const idle = passed === null || passed === undefined;

  return (
    <div
      className={`
        relative overflow-hidden rounded-xl border p-5 transition-all duration-500
        ${ok ? 'border-emerald-500/40 bg-emerald-900/20' : ''}
        ${fail ? 'border-red-500/40 bg-red-900/20' : ''}
        ${idle ? 'border-gray-700/40 bg-gray-800/20' : ''}
      `}
    >
      {/* glow bar */}
      <div
        className={`absolute inset-x-0 top-0 h-1 ${
          ok ? 'bg-gradient-to-r from-emerald-500 to-teal-400' : ''
        } ${fail ? 'bg-gradient-to-r from-red-500 to-orange-400' : ''} ${
          idle ? 'bg-gray-700' : ''
        }`}
      />

      <div className="flex items-center gap-4">
        {/* icon circle */}
        <div
          className={`
            flex h-12 w-12 shrink-0 items-center justify-center rounded-full
            ${ok ? 'bg-emerald-500/20 text-emerald-400 pulse-green' : ''}
            ${fail ? 'bg-red-500/20 text-red-400 pulse-red' : ''}
            ${idle ? 'bg-gray-700/30 text-gray-500' : ''}
          `}
        >
          {ok && <CheckCircle2 size={24} />}
          {fail && <XCircle size={24} />}
          {idle && <Icon size={24} />}
        </div>

        <div className="min-w-0 flex-1">
          <p
            className={`text-sm font-semibold uppercase tracking-wider ${
              ok ? 'text-emerald-400' : fail ? 'text-red-400' : 'text-gray-400'
            }`}
          >
            {label}
          </p>
          <p className="mt-1 truncate text-xs text-gray-400">
            {ok ? 'Conforme — validé ✓' : fail ? detail || 'Non conforme — bloqué' : 'En attente de vérification'}
          </p>
        </div>

        {/* status chip */}
        <span
          className={`
            shrink-0 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest
            ${ok ? 'bg-emerald-500/20 text-emerald-300' : ''}
            ${fail ? 'bg-red-500/20 text-red-300' : ''}
            ${idle ? 'bg-gray-700/40 text-gray-500' : ''}
          `}
        >
          {ok ? 'OK' : fail ? 'BLOQUÉ' : '—'}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Label Modal Component                                             */
/* ------------------------------------------------------------------ */
function LabelModal({ ofId, onClose }) {
  const [printing, setPrinting] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const printLabel = async (type) => {
    setPrinting(true);
    setError(null);
    setResult(null);
    try {
      const endpoint =
        type === 'pallet' ? '/labels/of' : '/labels/composant';
      const payload =
        type === 'pallet'
          ? { of_id_short: ofId }
          : { of_id_short: ofId, composant_type: 'bobine' };
      const { data } = await axios.post(`${LABELS_API}${endpoint}`, payload);
      setResult(
        `✓ Étiquette ${type === 'pallet' ? 'palette' : 'composant'} envoyée avec succès`
      );
    } catch (err) {
      setError(
        err.response?.data?.error || err.message || "Échec de l'impression"
      );
    } finally {
      setPrinting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="animate-fade-in-up w-full max-w-lg rounded-2xl border border-emerald-500/20 bg-[#111916] p-8 shadow-2xl shadow-emerald-900/20">
        {/* header */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20">
              <Printer size={20} className="text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Impression Étiquettes
              </h2>
              <p className="text-xs text-gray-400">OF : {ofId}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-gray-800 hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* print buttons */}
        <div className="space-y-3">
          <button
            disabled={printing}
            onClick={() => printLabel('pallet')}
            className="group flex w-full items-center gap-4 rounded-xl border border-emerald-500/20 bg-emerald-900/10 p-4 text-left transition-all hover:border-emerald-500/40 hover:bg-emerald-900/20 disabled:opacity-50"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-500/20 transition-transform group-hover:scale-110">
              <PackageCheck size={22} className="text-emerald-400" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-white">Étiquette Palette</p>
              <p className="text-xs text-gray-400">
                Imprimer l'étiquette palette pour l'OF
              </p>
            </div>
            <ChevronRight
              size={18}
              className="text-gray-600 transition-transform group-hover:translate-x-1 group-hover:text-emerald-400"
            />
          </button>

          <button
            disabled={printing}
            onClick={() => printLabel('component')}
            className="group flex w-full items-center gap-4 rounded-xl border border-teal-500/20 bg-teal-900/10 p-4 text-left transition-all hover:border-teal-500/40 hover:bg-teal-900/20 disabled:opacity-50"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-teal-500/20 transition-transform group-hover:scale-110">
              <Tag size={22} className="text-teal-400" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-white">Étiquette Composant</p>
              <p className="text-xs text-gray-400">
                Imprimer une étiquette composant (bobine)
              </p>
            </div>
            <ChevronRight
              size={18}
              className="text-gray-600 transition-transform group-hover:translate-x-1 group-hover:text-teal-400"
            />
          </button>
        </div>

        {/* feedback */}
        {printing && (
          <div className="mt-5 flex items-center gap-3 rounded-lg border border-emerald-500/20 bg-emerald-900/10 p-3">
            <Loader2 size={18} className="animate-spin text-emerald-400" />
            <p className="text-sm text-emerald-300">
              Envoi vers l'imprimante Zebra…
            </p>
          </div>
        )}
        {result && (
          <div className="mt-5 flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-900/20 p-3">
            <CheckCircle2 size={18} className="text-emerald-400" />
            <p className="text-sm text-emerald-300">{result}</p>
          </div>
        )}
        {error && (
          <div className="mt-5 flex items-center gap-3 rounded-lg border border-red-500/30 bg-red-900/20 p-3">
            <AlertTriangle size={18} className="text-red-400" />
            <p className="text-sm text-red-300">{error}</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main App                                                          */
/* ------------------------------------------------------------------ */
export default function App() {
  const [ofId, setOfId] = useState('');
  const [loading, setLoading] = useState(false);
  const [rules, setRules] = useState(null);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const checkRules = useCallback(async () => {
    if (!ofId.trim()) return;
    setLoading(true);
    setError(null);
    setRules(null);
    try {
      const { data } = await axios.get(
        `${RULES_API}/rules/${encodeURIComponent(ofId.trim())}/check`
      );
      setRules(data);
    } catch (err) {
      setError(
        err.response?.data?.error ||
          err.message ||
          'Erreur de connexion au serveur'
      );
    } finally {
      setLoading(false);
    }
  }, [ofId]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') checkRules();
  };

  const allPassed = rules && rules.all_passed === true;

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* background grid pattern */}
      <div className="pointer-events-none fixed inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(16,185,129,.3) 1px, transparent 1px), linear-gradient(90deg, rgba(16,185,129,.3) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* radial glow */}
      <div className="pointer-events-none fixed left-1/2 top-0 h-[600px] w-[800px] -translate-x-1/2 rounded-full bg-emerald-500/5 blur-[120px]" />

      <div className="relative mx-auto max-w-4xl px-6 py-10">
        {/* ── HEADER ── */}
        <header className="mb-12 text-center animate-fade-in-up">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-emerald-500/20 bg-emerald-500/10 shadow-lg shadow-emerald-900/30">
            <Factory size={32} className="text-emerald-400" />
          </div>
          <h1 className="bg-gradient-to-r from-emerald-300 via-teal-300 to-emerald-400 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent">
            TECPPP — Fiche de Suivi
          </h1>
          <p className="mt-2 text-sm text-gray-400">
            Tableau de bord opérateur · Contrôle temps-réel des règles de
            fabrication
          </p>
        </header>

        {/* ── SEARCH BAR ── */}
        <section className="animate-fade-in-up mb-10" style={{ animationDelay: '100ms' }}>
          <div className="relative">
            <div className="flex overflow-hidden rounded-2xl border border-emerald-500/20 bg-[#111916] shadow-xl shadow-emerald-900/10 transition-all focus-within:border-emerald-500/40 focus-within:shadow-emerald-900/20">
              <div className="flex shrink-0 items-center pl-5">
                <Search size={20} className="text-emerald-500/60" />
              </div>
              <input
                id="of-input"
                type="text"
                value={ofId}
                onChange={(e) => setOfId(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Entrez le numéro d'OF (ex. OF-2026-0042)"
                className="flex-1 bg-transparent px-4 py-4 text-sm text-white placeholder-gray-500 outline-none"
              />
              <button
                id="check-rules-btn"
                onClick={checkRules}
                disabled={loading || !ofId.trim()}
                className="m-2 flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-900/30 transition-all hover:from-emerald-500 hover:to-teal-500 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {loading ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Search size={16} />
                )}
                Vérifier
              </button>
            </div>
          </div>
        </section>

        {/* ── ERROR ── */}
        {error && (
          <div className="animate-fade-in-up mb-8 flex items-center gap-3 rounded-xl border border-red-500/30 bg-red-900/10 p-4">
            <AlertTriangle size={20} className="shrink-0 text-red-400" />
            <p className="text-sm text-red-300">{error}</p>
          </div>
        )}

        {/* ── RULES RESULTS ── */}
        {rules && (
          <div className="animate-fade-in-up space-y-8" style={{ animationDelay: '150ms' }}>
            {/* overall verdict */}
            <div
              className={`flex items-center gap-4 rounded-2xl border p-5 ${
                allPassed
                  ? 'border-emerald-500/30 bg-emerald-900/10'
                  : 'border-red-500/30 bg-red-900/10'
              }`}
            >
              <div
                className={`flex h-14 w-14 items-center justify-center rounded-xl ${
                  allPassed
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-red-500/20 text-red-400'
                }`}
              >
                {allPassed ? (
                  <CheckCircle2 size={28} />
                ) : (
                  <AlertTriangle size={28} />
                )}
              </div>
              <div>
                <p
                  className={`text-lg font-bold ${
                    allPassed ? 'text-emerald-300' : 'text-red-300'
                  }`}
                >
                  {allPassed
                    ? 'Toutes les règles sont satisfaites'
                    : 'Des contraintes sont non satisfaites'}
                </p>
                <p className="mt-0.5 text-xs text-gray-400">
                  OF : {rules.of_id_short || ofId} · Vérification à{' '}
                  {new Date().toLocaleTimeString('fr-FR')}
                </p>
              </div>
            </div>

            {/* rule cards grid */}
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="animate-slide-in-right" style={{ animationDelay: '50ms' }}>
                <StatusBadge
                  passed={rules.rules?.laize?.passed ?? null}
                  label="Laize"
                  icon={Layers}
                  detail={rules.rules?.laize?.message}
                />
              </div>
              <div className="animate-slide-in-right" style={{ animationDelay: '150ms' }}>
                <StatusBadge
                  passed={rules.rules?.colle?.passed ?? null}
                  label="Colle"
                  icon={Droplets}
                  detail={rules.rules?.colle?.message}
                />
              </div>
              <div className="animate-slide-in-right" style={{ animationDelay: '250ms' }}>
                <StatusBadge
                  passed={rules.rules?.bobines?.passed ?? null}
                  label="Bobines"
                  icon={CircleDot}
                  detail={rules.rules?.bobines?.message}
                />
              </div>
            </div>

            {/* Print button */}
            <div className="flex justify-center">
              <button
                id="open-print-modal-btn"
                onClick={() => setShowModal(true)}
                className="group flex items-center gap-3 rounded-xl border border-emerald-500/20 bg-gradient-to-r from-emerald-900/40 to-teal-900/40 px-8 py-3.5 text-sm font-semibold text-emerald-300 shadow-lg shadow-emerald-900/20 transition-all hover:border-emerald-500/40 hover:from-emerald-800/50 hover:to-teal-800/50 hover:text-white"
              >
                <Printer
                  size={18}
                  className="transition-transform group-hover:scale-110"
                />
                Imprimer Étiquettes
              </button>
            </div>
          </div>
        )}

        {/* ── EMPTY STATE ── */}
        {!rules && !error && !loading && (
          <div className="animate-fade-in-up mt-16 text-center" style={{ animationDelay: '200ms' }}>
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full border border-dashed border-gray-700 bg-gray-800/30">
              <Search size={32} className="text-gray-600" />
            </div>
            <p className="text-gray-500">
              Saisissez un numéro d'OF pour lancer la vérification des règles
            </p>
          </div>
        )}

        {/* ── FOOTER ── */}
        <footer className="mt-20 border-t border-gray-800/50 pt-6 text-center">
          <p className="text-xs text-gray-600">
            TECPPP — Système MES · Contrôle Fabrication ·{' '}
            <span className="text-emerald-600">v1.0.0</span>
          </p>
        </footer>
      </div>

      {/* ── LABEL MODAL ── */}
      {showModal && (
        <LabelModal ofId={ofId} onClose={() => setShowModal(false)} />
      )}
    </div>
  );
}
