const axios = require('axios');

// Robust HTTP Client for Zebra Printers
// Hardware printers may take longer to respond, hence 10s default timeout
const printerClient = axios.create({
  timeout: 10000, 
});

// Retry logic for intermittent network or queue issues
printerClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const config = error.config;
    if (!config || !config.retry) {
      return Promise.reject(error);
    }
    config.retryCount = config.retryCount || 0;
    
    if (config.retryCount >= config.retry) {
      return Promise.reject(error);
    }
    
    config.retryCount += 1;
    const delay = config.retryDelay || 2000;
    console.warn(`[Printer HTTP] Retrying request to ${config.url} (${config.retryCount}/${config.retry})...`);
    
    await new Promise(resolve => setTimeout(resolve, delay));
    return printerClient(config);
  }
);

const zebraAdapter = {
  printZPL: async (zpl) => {
    const printerIp = process.env.ZEBRA_PRINTER_IP || '127.0.0.1';
    
    // We infer mock setup from local IPs to map to our 4002 mock server structure,
    // otherwise fallback to a standard HTTP raw ZPL endpoint assumption if configured real
    const isMock = printerIp === '127.0.0.1' || printerIp === 'localhost';
    const url = isMock 
      ? `http://${printerIp}:4002/zebra/print` 
      : `http://${printerIp}/print`; // Standard POST path for some Link-OS setups

    try {
      const response = await printerClient.post(url, { zpl }, { retry: 3, retryDelay: 2000 });
      return response.data;
    } catch (err) {
      console.error(`Zebra Printer Adapter Error: ${err.message}`);
      // Throw allowing the service to handle if it needs an explicit failure
      throw err;
    }
  }
};

module.exports = { zebraAdapter };
