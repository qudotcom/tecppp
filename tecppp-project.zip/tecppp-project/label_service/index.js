require('dotenv').config();
const express = require('express');
const redis = require('redis');
const Joi = require('joi');
const cors = require('cors');
const { zebraAdapter } = require('./adapters/httpClient');

const app = express();
app.use(cors());
app.use(express.json());

// Redis Client
const redisClient = redis.createClient({
    url: `redis://${process.env.REDIS_HOST || 'localhost'}:${process.env.REDIS_PORT || 6379}`
});

redisClient.on('error', (err) => console.log('Redis Client Error', err));

// Connect to Redis asynchronously
(async () => {
    try {
        await redisClient.connect();
        console.log('Connected to Redis');
    } catch (err) {
        console.error('Failed to connect to Redis', err);
    }
})();

// Schema Definition based on contracts/qr_payload.schema.json
const composantSchema = Joi.object({
    type: Joi.string().valid('bobine_papier', 'bobine_poignet', 'bobine_patch', 'colle').required(),
    lot_id: Joi.string().required(),
    ref_article: Joi.string().required(),
    laize: Joi.alternatives().try(Joi.number(), Joi.valid(null)).required(),
    grammage: Joi.alternatives().try(Joi.number(), Joi.valid(null)).required(),
    fsc_tier: Joi.string().valid('F1', 'F2', 'F3', 'P1', 'P2', 'P3').allow(null).required()
});

/**
 * POST /labels/of
 * Generates ZPL commands for Manufacturing Orders (OFs).
 */
app.post('/labels/of', (req, res) => {
    const { impression, of_short_code, code_article, conditionnement } = req.body;
    
    if (!impression || !of_short_code || !code_article || !conditionnement) {
        return res.status(400).json({ error: 'Missing required fields: impression, of_short_code, code_article, conditionnement' });
    }

    // Generate ZPL adhering to the exact requested structure
    const zpl = `^XA
^FO50,50^A0N,50,50^FD${impression}^FS
^FO50,110^A0N,50,50^FD${of_short_code}^FS
^FO50,170^A0N,50,50^FD${code_article}^FS
^FO50,230^A0N,50,50^FD${conditionnement}^FS
^XZ`;

    // Transmit to Zebra Printer
    zebraAdapter.printZPL(zpl).catch(err => {
        console.warn('Printer transmission failed or printer unavailable (check ZEBRA_PRINTER_IP configuration):', err.message);
    });

    return res.json({ success: true, zpl });
});

/**
 * POST /labels/composant
 * Generates ZPL commands containing a QR code for internal material tracking.
 * Uses the composantSchema matching qr_payload.schema.json
 */
app.post('/labels/composant', (req, res) => {
    const { error, value } = composantSchema.validate(req.body);
    
    if (error) {
        return res.status(400).json({ error: 'Invalid payload according to schema', details: error.details });
    }

    // Stringify payload to embed in QR ZPL
    const jsonString = JSON.stringify(value);
    
    // ZPL wrapper for a QR code
    // ^BQN: QR code format setup
    // ^FDQA,: Start of data for QR, 'QA,' specifies encoding and error correction
    const zpl = `^XA
^FO50,50^BQN,2,5^FDQA,${jsonString}^FS
^XZ`;

    // Transmit to Zebra Printer
    zebraAdapter.printZPL(zpl).catch(err => {
        console.warn('Printer transmission failed or printer unavailable (check ZEBRA_PRINTER_IP configuration):', err.message);
    });

    return res.json({ success: true, zpl });
});

/**
 * GET /labels/validate
 * Decodes a raw QR string (from query param), ensures it matches the schema,
 * and emits a Redis event if valid.
 */
app.get('/labels/validate', async (req, res) => {
    const { qr } = req.query;
    if (!qr) {
        return res.status(400).json({ error: 'Missing qr parameter' });
    }

    try {
        const parsed = JSON.parse(qr);
        const { error, value } = composantSchema.validate(parsed);
        
        if (error) {
            return res.status(400).json({ error: 'Validation failed against schema', details: error.details });
        }

        // Emit 'scan.composant' event using Redis
        if (redisClient.isOpen) {
            await redisClient.publish('scan.composant', JSON.stringify(value));
            console.log(`[Event Emitted] scan.composant:`, value);
        } else {
            console.warn('Redis is not connected. Event not published.');
        }

        return res.json({ success: true, payload: value });
    } catch (err) {
        return res.status(400).json({ error: 'Invalid JSON strictly expected', details: err.message });
    }
});

const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
    console.log(`Label service listening on port ${PORT}`);
});
