const axios = require('axios');

// Robust HTTP Client for Evocon & Sage X3
const createClient = (baseURL, timeout = 5000) => {
  const client = axios.create({
    baseURL,
    timeout,
  });

  client.interceptors.response.use(
    (response) => response,
    async (error) => {
      const config = error.config;
      if (!config || !config.retry) {
        return Promise.reject(error);
      }
      config.retryCount = config.retryCount || 0;
      
      if (config.retryCount >= config.retry) {
        return Promise.reject(error);
      }
      
      config.retryCount += 1;
      const delay = config.retryDelay || 1000;
      console.warn(`[HTTP] Retrying request to ${config.url} (${config.retryCount}/${config.retry})...`);
      
      await new Promise(resolve => setTimeout(resolve, delay));
      return client(config);
    }
  );

  return client;
};

// Setup specific clients
const sageClient = createClient(process.env.SAGE_API_URL || 'http://localhost:4002/sage', 8000);
const evoconClient = createClient(process.env.EVOCON_OEE_ENDPOINT || 'http://localhost:4002/evocon/oee', 5000);

const sageAdapter = {
  startOF: async (ofId) => {
    try {
      return await sageClient.post('/of/start', { ofId }, { retry: 3, retryDelay: 2000 });
    } catch (err) {
      console.error(`Sage API Error (startOF): ${err.message}`);
      throw err;
    }
  },
  completePallet: async (ofId) => {
    try {
      return await sageClient.post('/pallet/complete', { ofId }, { retry: 3, retryDelay: 2000 });
    } catch (err) {
      console.error(`Sage API Error (completePallet): ${err.message}`);
      throw err;
    }
  },
  completeOF: async (ofId) => {
    try {
      return await sageClient.post('/of/complete', { ofId }, { retry: 3, retryDelay: 2000 });
    } catch (err) {
      console.error(`Sage API Error (completeOF): ${err.message}`);
      throw err;
    }
  }
};

const evoconAdapter = {
  sendOEEEvent: async (ofId, event) => {
    try {
      return await evoconClient.post('', { of_id: ofId, event }, { retry: 3, retryDelay: 1000 });
    } catch (err) {
      console.error(`Evocon API Error (sendOEEEvent): ${err.message}`);
      throw err;
    }
  }
};

module.exports = { sageAdapter, evoconAdapter };
