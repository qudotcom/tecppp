require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Agent A database schema read-only access (but we also write our audit log, so we need write access to our table).
// We assume DB URL is provided in env var DATABASE_URL or defaults to localhost tecpap_mes
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  user: process.env.DB_USER || 'admin',
  password: process.env.DB_PASSWORD || 'password123',
  database: process.env.DB_NAME || 'manufacturing_orders'
});

// Initialize audit log table in the default schema.
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id SERIAL PRIMARY KEY,
        of_id_short VARCHAR(50),
        rule_name VARCHAR(100),
        blocked BOOLEAN,
        reason TEXT,
        checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("Audit logs table ready.");
  } catch (err) {
    console.error("Failed to init audit log table:", err);
  }
})();

async function logAudit(of_id_short, rule_name, blocked, reason) {
  try {
    await pool.query(
      `INSERT INTO audit_logs (of_id_short, rule_name, blocked, reason) VALUES ($1, $2, $3, $4)`,
      [of_id_short, rule_name, blocked, reason]
    );
  } catch (err) {
    console.error("Audit log failed:", err);
  }
}

app.get('/rules/:of_id_short/check', async (req, res) => {
  const { of_id_short } = req.params;
  let decodedOfId;
  try {
    decodedOfId = decodeURIComponent(of_id_short);
  } catch (e) {
    return res.status(400).json({ error: "Invalid OF ID encoding" });
  }

  try {
    // 1. Fetch OF details
    let ofResult;
    try {
      ofResult = await pool.query(
        `SELECT * FROM manufacturing_orders WHERE of_id_short = $1`,
        [decodedOfId]
      );
    } catch (dbErr) {
      return res.status(500).json({ error: "Database query failed", details: dbErr.message });
    }

    if (ofResult.rowCount === 0) {
      return res.status(404).json({ error: "OF not found" });
    }

    const ofData = ofResult.rows[0];
    const requiredLaize = ofData.specs_laize !== undefined ? Number(ofData.specs_laize) : null;
    const requiredGrammage = ofData.specs_grammage !== undefined ? Number(ofData.specs_grammage) : null;
    const requiredTier = ofData.fsc_required_tier;

    // 2. Fetch scanned components
    let scansResult;
    try {
      scansResult = await pool.query(
        `SELECT * FROM scanned_components WHERE of_id_short = $1`,
        [decodedOfId]
      );
    } catch (dbErr) {
      return res.status(500).json({ error: "Database query failed", details: dbErr.message });
    }
    const scans = scansResult.rows;
    const paperScans = scans.filter(s => s.type === 'bobine_papier');

    // ── Evaluate each rule independently ──

    // Rule 1: Laize & Grammage spec matching
    let laizeResult = { passed: true, message: `Laize ${requiredLaize} mm, Grammage ${requiredGrammage} g/m² — conforme` };
    for (const scan of paperScans) {
      const scanLaize = scan.laize !== undefined ? Number(scan.laize) : null;
      const scanGrammage = scan.grammage !== undefined ? Number(scan.grammage) : null;
      if (requiredLaize !== null && requiredGrammage !== null) {
        if (scanLaize !== requiredLaize || scanGrammage !== requiredGrammage) {
          laizeResult = {
            passed: false,
            message: `Spécification incorrecte. Attendu L:${requiredLaize} G:${requiredGrammage}, Trouvé L:${scanLaize} G:${scanGrammage}`
          };
          await logAudit(decodedOfId, "Spec Matching", true, laizeResult.message);
          break;
        }
      }
    }
    if (laizeResult.passed) {
      await logAudit(decodedOfId, "Spec Matching", false, laizeResult.message);
    }

    // Rule 2: FSC Tier matching (mapped to "colle" badge in frontend)
    let colleResult = { passed: true, message: requiredTier ? `Tier FSC ${requiredTier} — conforme` : 'Aucune exigence FSC' };
    if (requiredTier) {
      for (const scan of paperScans) {
        if (scan.fsc_tier && scan.fsc_tier !== requiredTier) {
          colleResult = {
            passed: false,
            message: `Non-conformité FSC. Attendu: ${requiredTier}, Trouvé: ${scan.fsc_tier}`
          };
          await logAudit(decodedOfId, "FSC Tier", true, colleResult.message);
          break;
        }
      }
    }
    if (colleResult.passed) {
      await logAudit(decodedOfId, "FSC Tier", false, colleResult.message);
    }

    // Rule 3: BOM Completion
    const hasPaper = scans.some(s => s.type === 'bobine_papier');
    const hasHandles = scans.some(s => s.type === 'bobine_poignet');
    const hasPatches = scans.some(s => s.type === 'bobine_patch');
    const hasGlue = scans.some(s => s.type === 'colle');
    const bomComplete = hasPaper && hasHandles && hasPatches && hasGlue;

    let bobinesResult;
    if (bomComplete) {
      bobinesResult = { passed: true, message: 'Tous les composants scannés (papier, poignées, patches, colle)' };
      await logAudit(decodedOfId, "BOM Completion", false, bobinesResult.message);
    } else {
      const missing = [];
      if (!hasPaper) missing.push("papier");
      if (!hasHandles) missing.push("poignées");
      if (!hasPatches) missing.push("patches");
      if (!hasGlue) missing.push("colle");
      bobinesResult = {
        passed: false,
        message: `Composants manquants : ${missing.join(", ")}`
      };
      await logAudit(decodedOfId, "BOM Completion", true, bobinesResult.message);
    }

    // ── Build response matching frontend contract ──
    const allPassed = laizeResult.passed && colleResult.passed && bobinesResult.passed;

    return res.json({
      of_id_short: decodedOfId,
      all_passed: allPassed,
      rules: {
        laize: laizeResult,
        colle: colleResult,
        bobines: bobinesResult
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error during rule evaluation." });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
    console.log(`Rules Engine listening on port ${PORT}`);
});
