#!/bin/sh
set -e

# Configuration for Postgres connection
host="${DB_HOST:-postgres}"
port="${DB_PORT:-5432}"

echo "Waiting for PostgreSQL at $host:$port..."

# Wait until Postgres port is responding
while ! nc -z "$host" "$port"; do
  sleep 1
done

echo "PostgreSQL is up! Starting application..."

# Execute the main process
exec "$@"
