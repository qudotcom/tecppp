const axios = require('axios');
const SwaggerParser = require('swagger-parser');
const path = require('path');
const { exec } = require('child_process');

let rulesEngineProcess;
let labelServiceProcess;

// We need to wait for services to boot up
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

describe('API Contract Tests', () => {
    let apiSpec;

    beforeAll(async () => {
        const specPath = path.resolve(__dirname, '../../contracts/api.openapi.yaml');
        apiSpec = await SwaggerParser.parse(specPath);
        
        // Let's assume services are running or started outside
        // For self-contained tests, we'd start them here.
        // We rely on the live services actively running on port 4000 (rules) and 4001 (labels)
        await delay(2000); // Wait for boot
    }, 10000);

    afterAll(() => {
        // No processes to kill
    });

    test('GET /rules/{of_id_short}/check responds correctly', async () => {
        try {
            // We expect this to follow the schema, even if 404
            const response = await axios.get('http://localhost:4000/rules/999/check', { validateStatus: false });
            expect(response.status).toBeDefined();
            // Contract validation would ideally use ajv against apiSpec.paths['/rules/{of_id_short}/check'].responses['200']
            if (response.status === 200) {
                expect(typeof response.data.blocked).toBe('boolean');
                expect(typeof response.data.reason).toBe('string');
            }
        } catch (e) {
            console.error(e);
            throw e;
        }
    });

    test('POST /labels/of responds correctly', async () => {
        const response = await axios.post('http://localhost:4001/labels/of', {
            impression: "Test",
            of_short_code: "123",
            code_article: "ABC",
            conditionnement: "Pallet"
        });
        expect(response.status).toBe(200);
        expect(response.data.success).toBe(true);
        expect(typeof response.data.zpl).toBe('string');
    });

    test('POST /labels/composant responds correctly', async () => {
        const response = await axios.post('http://localhost:4001/labels/composant', {
            type: "colle",
            lot_id: "L1",
            ref_article: "R1",
            laize: null,
            grammage: null,
            fsc_tier: null
        });
        expect(response.status).toBe(200);
        expect(response.data.success).toBe(true);
        expect(typeof response.data.zpl).toBe('string');
    });
});
