const { Pool } = require('pg');
const axios = require('axios');
const path = require('path');
const { exec } = require('child_process');
const mockServer = require('../mocks/mock_server');

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'admin',
    password: process.env.DB_PASSWORD || 'password123',
    database: process.env.DB_NAME || 'manufacturing_orders'
});

let rulesEngineProcess;

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

describe('E2E: Fiche de Suivi Flow', () => {
  const OF_ID = '26/9999';

  beforeAll(async () => {
    // 1. Initialize Mock Server for external calls
    await mockServer.start(4002);

    // 2. We use the actively running rules_engine on port 4000

    await delay(2000); // Wait for rule engine boot

    // 3. Setup Mock Agent A Schema
    await pool.query(`
      CREATE TABLE IF NOT EXISTS manufacturing_orders (
        of_id_short VARCHAR(50) PRIMARY KEY,
        specs_laize NUMERIC,
        specs_grammage NUMERIC,
        fsc_required_tier VARCHAR(10)
      );
    `);
    
    await pool.query(`
      CREATE TABLE IF NOT EXISTS scanned_components (
        id SERIAL PRIMARY KEY,
        of_id_short VARCHAR(50),
        type VARCHAR(50),
        laize NUMERIC,
        grammage NUMERIC,
        fsc_tier VARCHAR(10)
      );
    `);

    // Clean up before test
    await pool.query(`DELETE FROM audit_logs WHERE of_id_short = $1`, [OF_ID]);
    await pool.query(`DELETE FROM scanned_components WHERE of_id_short = $1`, [OF_ID]);
    await pool.query(`DELETE FROM manufacturing_orders WHERE of_id_short = $1`, [OF_ID]);
  }, 10000);

  afterAll(async () => {
    await mockServer.stop();
    await pool.end();
  });

  test('Fiche de Suivi Integration Flow', async () => {
    // Step 1: Trigger of.created (Mock Agent A persisting event to DB)
    await pool.query(
      `INSERT INTO manufacturing_orders (of_id_short, specs_laize, specs_grammage, fsc_required_tier) VALUES ($1, $2, $3, $4)`,
      [OF_ID, 98, 80, 'F1']
    );

    // Step 2: Setup Machine (Mock endpoint call to ERP)
    const setupRes = await axios.post('http://localhost:4002/sage/of/start');
    expect(setupRes.status).toBe(200);

    // Step 3: Scan Paper (Fail Laize check)
    // Insert wrong paper (Laize 90 instead of 98)
    await pool.query(
      `INSERT INTO scanned_components (of_id_short, type, laize, grammage, fsc_tier) VALUES ($1, $2, $3, $4, $5)`,
      [OF_ID, 'bobine_papier', 90, 80, 'F1']
    );

    // Call rule check - Should block
    let check1 = await axios.get(`http://localhost:4000/rules/${encodeURIComponent(OF_ID)}/check`);
    expect(check1.status).toBe(200);
    expect(check1.data.blocked).toBe(true);
    expect(check1.data.reason).toMatch(/Bobine specs mismatch/);

    // Clear wrong scan to simulate operator correcting it
    await pool.query(`DELETE FROM scanned_components WHERE of_id_short = $1 AND type = 'bobine_papier'`, [OF_ID]);

    // Step 4: Scan Paper (Pass)
    await pool.query(
      `INSERT INTO scanned_components (of_id_short, type, laize, grammage, fsc_tier) VALUES ($1, $2, $3, $4, $5)`,
      [OF_ID, 'bobine_papier', 98, 80, 'F1']
    );

    let check2 = await axios.get(`http://localhost:4000/rules/${encodeURIComponent(OF_ID)}/check`);
    // Still blocked because BOM is incomplete (Rule 3)
    expect(check2.data.blocked).toBe(true);
    expect(check2.data.reason).toMatch(/Missing components/);

    // Step 5: Scan remaining components (Glue, Handles, Patches)
    await pool.query(
        `INSERT INTO scanned_components (of_id_short, type) VALUES ($1, $2), ($1, $3), ($1, $4)`,
        [OF_ID, 'colle', 'bobine_poignet', 'bobine_patch']
    );

    const check3 = await axios.get(`http://localhost:4000/rules/${encodeURIComponent(OF_ID)}/check`);
    expect(check3.data.blocked).toBe(false);
    expect(check3.data.reason).toBe("All rules passed.");

    // Step 6: Start OF (Hitting evocon / sage mock)
    const oeeRes = await axios.post('http://localhost:4002/evocon/oee', { of_id: OF_ID, event: 'START' });
    expect(oeeRes.data.success).toBe(true);

    // Step 7: Complete Pallet
    const palletRes = await axios.post('http://localhost:4002/sage/pallet/complete');
    expect(palletRes.status).toBe(200);

    // Step 8: Complete OF
    const completeRes = await axios.post('http://localhost:4002/sage/of/complete');
    expect(completeRes.status).toBe(200);

    // Verify audit logs
    const auditRes = await pool.query('SELECT * FROM audit_logs WHERE of_id_short = $1 ORDER BY id ASC', [OF_ID]);
    expect(auditRes.rows.length).toBeGreaterThan(0);
  });
});
