const express = require('express');

const mockServer = express();
mockServer.use(express.json());

// Sage X3 Mocks
mockServer.post('/sage/of/start', (req, res) => res.json({ status: 'started' }));
mockServer.post('/sage/of/complete', (req, res) => res.json({ status: 'completed' }));
mockServer.post('/sage/pallet/complete', (req, res) => res.json({ status: 'pallet_registered' }));

// Zebra Printers Mocks
mockServer.post('/zebra/print', (req, res) => {
    const { zpl } = req.body;
    if (!zpl) return res.status(400).json({ error: 'No ZPL provided' });
    res.json({ success: true, message: 'Printed successfully' });
});

// Evocon API Mocks
mockServer.post('/evocon/oee', (req, res) => {
    res.json({ success: true, recorded: req.body });
});

let server;

module.exports = {
    start: (port) => {
        return new Promise((resolve) => {
            server = mockServer.listen(port, () => resolve(server));
        });
    },
    stop: () => {
        return new Promise((resolve) => {
            if (server) {
                server.close(() => resolve());
            } else {
                resolve();
            }
        });
    },
    app: mockServer
};
